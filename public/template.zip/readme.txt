Guide to creating your own pack for Guess Who Card Generator
Guide Version: 1

General recommendations

1. Pack format
   * The pack must be in ZIP format.
   * Other formats will not be uploaded.

2. Pack structure
   * The pack can contain ONE or MULTIPLE folders of the following types:
     backgrounds, cards, categories, sets
   * It is NOT mandatory for the pack to contain all folders. The pack will upload even if it contains only one type of data.

3. Configuration files
   * Each folder of type backgrounds, cards, categories, or sets must have a subfolder "images", where all corresponding images are stored.
   * Each folder must have the corresponding config file:
     backgrounds → backgroundConfig.json
     cards → cardConfig.json
     categories → categoryList.json
     sets → setConfig.json
   * Config files contain information about files, localizations, and relationships between objects.

4. Unique ID
   * Always try to provide unique identifiers.
   * Example: instead of google, use something like myUsername-google.
   * This helps avoid conflicts with packs from other users.

5. Naming format (kebab-case)
   * For all object IDs, file names, and directories, it is recommended to use kebab-case (lowercase letters with a hyphen).
   * Try to give clear and understandable names
   * Examples:
     Object IDs: my-username-google, first-card, set-special
     Image files: avatar-man-01.png, background-space.jpg
     Directories: forest-animals, fast-cars, french-cuisine
     Incorrect: myUsernameGoogle, Am_01.png, buBabEb
   * Using a consistent naming style prevents errors during upload and improves readability.

6. Images
   * All major image formats are supported: PNG, JPG, JPEG, WebP, SVG, BMP, GIF...
   * It is recommended to use images with an aspect ratio of 2:3 or 1:1.
   * Try to limit image resolution to 1000px on the larger side.
   * For convenience, it is better to use file names that correspond to object IDs in the config.

7. Localization
   * In the config, you can specify object names in different languages.
   * Even if this language is not in the website’s language list, you can still use any language code by clicking the button located to the right of the site’s language selector.

8. Tips for creating packs
   * Make sure all IDs are unique even within your own pack.
   * You can create a pack with only one type of data, for example, only cards or only backgrounds.
   * Check the correctness of JSON configs — format errors can cause the pack to fail uploading.
